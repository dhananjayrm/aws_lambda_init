def lambda_handler_1(event, context):
    message = 'Hello Himanshi'
    return {
        'message': message
    }